from django.apps import AppConfig


class PublicSiteConfig(AppConfig):
    name = 'public_site'
